import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/JoseVsc/Tuga-TV-Vsc/master/vsctuga.xml'
addon = xbmcaddon.Addon('plugin.video.TugaTVVsc')